TAB_MAPPING = {
    [0] = "World Map",
    
    [1] = "Area Maps/Area A/A-1, -3, -4", -- "a1",
    [2] = "Area Maps/Area A/A-2", -- "a2",
    [3] = "Area Maps/Area A/A-1, -3, -4", -- "a3",
    [4] = "Area Maps/Area A/A-1, -3, -4", -- "a4",

    [5] = "Area Maps/Area B/B-1, -3, -4", -- "b1",
    [6] = "Area Maps/Area B/B-2", -- "b2",
    [7] = "Area Maps/Area B/B-1, -3, -4", -- "b3",
    [8] = "Area Maps/Area B/B-1, -3, -4", -- "b4",

    [9] = "Area Maps/Area C/C-1, -3", -- "c1",
    [10] = "Area Maps/Area C/C-2", --[a]  -- "c2",
    [11] = "Area Maps/Area C/C-1, -3",--[b] -- "c3",
    
    --[f] = "Area Maps/Area D/D-1", -- "d1",

    [16] = "Area Maps/Area D/D-2", -- "d2",
    [17] = "Area Maps/Area D/D-3", -- "d3",
    
    [12] = "Area Maps/Area D/D-4, 5", -- "d4",
    [13] = "Area Maps/Area D/D-4, 5", -- "d5",

    [14] = "Area Maps/Area E/E-1, 2", -- "e1",
    [15] = "Area Maps/Area E/E-1, 2", -- "e2",
    --[16] = "Area Maps/Area E/E-3, 4, 6", -- "e3",
    --[17] = "Area Maps/Area E/E-3, 4, 6", -- "e4",
    [18] = "Area Maps/Area E/E-5, 7, 8", -- "e5",
    [19] = "Area Maps/Area E/E-3, 4, 6", -- "e6",
    --[t6] = "Area Maps/Area E/E-5, 7, 8", --[1a] -- "e7",
    --[1b] = "Area Maps/Area E/E-5, 7, 8", -- "e8",
    
    --[1c] = "Area Maps/Area F/F-1, 2", -- "f1",
    --[1d] = "Area Maps/Area F/F-1, 2", -- "ft",
    --[1e] = "Area Maps/Area F/F-3", -- "f3",
    --[1f] = "Area Maps/Area F/F-4, 5", -- "f4",
    [20] = "Area Maps/Area F/F-4, 5", -- "f5",

    [21] = "Area Maps/Area G/G-1", -- "g1",
    [22] = "Area Maps/Area G/G-2, 3", -- "g2",
    [23] = "Area Maps/Area G/G-2, 3", -- "g3",
    [24] = "Area Maps/Area G/G-4, 5", -- "g4",
    [25] = "Area Maps/Area G/G-4, 5", -- "g5",

    [26] = "Area Maps/Area H/H-1, 2", -- "h1",
    [27] = "Area Maps/Area H/H-1, 2", -- "h2",
    [28] = "Area Maps/Area H/H-3", -- "h3",
    [29] = "Area Maps/Area H/H-4", -- "h4",

    --[2a] = "Area Maps/Area I/I-1, 2", -- "i1",
    --[2b] = "Area Maps/Area I/I-1, 2", -- "i2",
    --[2c] = "Area Maps/Area I/I-3", -- "i3",
    --[2d] = "Area Maps/Area I/I-4, 5", -- "i4",
    --[2e] = "Area Maps/Area I/I-4, 5", -- "i5",
    
    --[2f] = "Area Maps/Area J/J-1", -- "j1",
    [30] = "Area Maps/Area J/J-2", -- "jt",
    [31] = "Area Maps/Area J/J-3, 4, 5", -- "j3",
    [32] = "Area Maps/Area J/J-3, 4, 5", -- "j4",
    [33] = "Area Maps/Area J/J-3, 4, 5", -- "j5",

    [34] = "Area Maps/Area K/K-1, 2", -- "k1",
    [35] = "Area Maps/Area K/K-1, 2", -- "k2",
    [36] = "Area Maps/Area K/K-3", -- "k3",
    [37] = "Area Maps/Area K/K-4", -- "k4",
    [38] = "Area Maps/Area K/K-5", -- "k5",

    [39] = "Area Maps/Area L", -- "l1",
    --[3a] = "Area Maps/Area L", -- "l2",
    --[3b] = "Area Maps/Area L", -- "l3",
    --[3c] = "Area Maps/Area L", -- "l4",
    
    --[3d] = "Area Maps/Area M/M-1", -- "m1",
    --[3e] = "Area Maps/Area M/M-2, 3", -- "mt",
    --[3f] = "Area Maps/Area M/M-2, 3", -- "m3",

    [40] = "Area Maps/Area N", -- "n1",

    [41] = "Area Maps/Area O/O-1", -- "o1",
    [42] = "Area Maps/Area O/O-2", -- "ot",
    
    [43] = "Guardian HQ", -- "x1",
    [44] = "Guardian HQ", -- "xt",
    [45] = "Guardian HQ", -- "x3",

    [46] = "World Map",
    
    [70] = "World Map"
}