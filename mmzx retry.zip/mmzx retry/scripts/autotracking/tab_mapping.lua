TAB_MAPPING = {
    [0] = "World Map",
    
    [1] = "Area Maps/Area A/A-1, -3, -4", -- "a1",
    [2] = "Area Maps/Area A/A-2", -- "a2",
    [3] = "Area Maps/Area A/A-1, -3, -4", -- "a3",
    [4] = "Area Maps/Area A/A-1, -3, -4", -- "a4",

    [5] = "Area Maps/Area B/B-1, -3, -4", -- "b1",
    [6] = "Area Maps/Area B/B-2", -- "b2",
    [7] = "Area Maps/Area B/B-1, -3, -4", -- "b3",
    [8] = "Area Maps/Area B/B-1, -3, -4", -- "b4",

    [9] = "Area Maps/Area C/C-1, -3", -- "c1",
    [10] = "Area Maps/Area C/C-2", -- "c2",
    [11] = "Area Maps/Area C/C-1, -3", -- "c3",
    
    [15] = "Area Maps/Area D/D-1", -- "d1",
    [16] = "Area Maps/Area D/D-2", -- "d2",
    [17] = "Area Maps/Area D/D-3", -- "d3",
    [18] = "Area Maps/Area D/D-4, 5", -- "d4",
    [19] = "Area Maps/Area D/D-4, 5", -- "d5",

    [20] = "Area Maps/Area E/E-1, 2", -- "e1",
    [21] = "Area Maps/Area E/E-1, 2", -- "e2",
    [22] = "Area Maps/Area E/E-3, 4, 6", -- "e3",
    [23] = "Area Maps/Area E/E-3, 4, 6", -- "e4",
    [24] = "Area Maps/Area E/E-5, 7, 8", -- "e5",
    [25] = "Area Maps/Area E/E-3, 4, 6", -- "e6",
    [26] = "Area Maps/Area E/E-5, 7, 8", -- "e7",
    [27] = "Area Maps/Area E/E-5, 7, 8", -- "e8",
    
    [28] = "Area Maps/Area F/F-1, 2", -- "f1",
    [29] = "Area Maps/Area F/F-1, 2", -- "ft",
    [30] = "Area Maps/Area F/F-3", -- "f3",
    [31] = "Area Maps/Area F/F-4, 5", -- "f4",
    [32] = "Area Maps/Area F/F-4, 5", -- "f5",

    [33] = "Area Maps/Area G/G-1", -- "g1",
    [34] = "Area Maps/Area G/G-2, 3", -- "g2",
    [35] = "Area Maps/Area G/G-2, 3", -- "g3",
    [36] = "Area Maps/Area G/G-4, 5", -- "g4",
    [37] = "Area Maps/Area G/G-4, 5", -- "g5",

    [38] = "Area Maps/Area H/H-1, 2", -- "h1",
    [39] = "Area Maps/Area H/H-1, 2", -- "h2",
    [40] = "Area Maps/Area H/H-3", -- "h3",
    [41] = "Area Maps/Area H/H-4", -- "h4",

    [42] = "Area Maps/Area I/I-1, 2", -- "i1",
    [43] = "Area Maps/Area I/I-1, 2", -- "i2",
    [44] = "Area Maps/Area I/I-3", -- "i3",
    [45] = "Area Maps/Area I/I-4, 5", -- "i4",
    [46] = "Area Maps/Area I/I-4, 5", -- "i5",
    
    [47] = "Area Maps/Area J/J-1", -- "j1",
    [48] = "Area Maps/Area J/J-2", -- "jt",
    [49] = "Area Maps/Area J/J-3, 4, 5", -- "j3",
    [50] = "Area Maps/Area J/J-3, 4, 5", -- "j4",
    [51] = "Area Maps/Area J/J-3, 4, 5", -- "j5",

    [52] = "Area Maps/Area K/K-1, 2", -- "k1",
    [53] = "Area Maps/Area K/K-1, 2", -- "k2",
    [54] = "Area Maps/Area K/K-3", -- "k3",
    [55] = "Area Maps/Area K/K-4", -- "k4",
    [56] = "Area Maps/Area K/K-5", -- "k5",

    [57] = "Area Maps/Area L", -- "l1",
    [58] = "Area Maps/Area L", -- "l2",
    [59] = "Area Maps/Area L", -- "l3",
    [60] = "Area Maps/Area L", -- "l4",
    
    [61] = "Area Maps/Area M/M-1", -- "m1",
    [62] = "Area Maps/Area M/M-2, 3", -- "mt",
    [63] = "Area Maps/Area M/M-2, 3", -- "m3",

    [64] = "Area Maps/Area N", -- "n1",

    [65] = "Area Maps/Area O/O-1", -- "o1",
    [66] = "Area Maps/Area O/O-2", -- "ot",
    
    [67] = "Guardian HQ", -- "x1",
    [68] = "Guardian HQ", -- "xt",
    [69] = "Guardian HQ", -- "x3",
    
    [70] = "World Map", -- transerver
    
    [71] = "Area Maps/Area D/D-4, 5", --refights
}