-- this is an example/default implementation for AP autotracking
-- it will use the mappings defined in item_mapping.lua and location_mapping.lua to track items and locations via their ids
-- it will also keep track of the current index of on_item messages in CUR_INDEX
-- addition it will keep track of what items are local items and which one are remote using the globals LOCAL_ITEMS and GLOBAL_ITEMS
-- this is useful since remote items will not reset but local items might
-- if you run into issues when touching A LOT of items/locations here, see the comment about Tracker.AllowDeferredLogicUpdate in autotracking.lua
ScriptHost:LoadScript("scripts/autotracking/item_mapping.lua")
ScriptHost:LoadScript("scripts/autotracking/location_mapping.lua")
ScriptHost:LoadScript("scripts/autotracking/tab_mapping.lua")
-- used for hint tracking to quickly map hint status to a value from the Highlight enum
HINT_STATUS_MAPPING = {}
if Highlight then
	HINT_STATUS_MAPPING = {
		[20] = Highlight.Avoid,
		[40] = Highlight.None,
		[10] = Highlight.NoPriority,
		[0] = Highlight.Unspecified,
		[30] = Highlight.Priority,
	}
end

CUR_INDEX = -1
LOCAL_ITEMS = {}
GLOBAL_ITEMS = {}
EVENT_ID = ""
TAB_ID = ""

-- gets the data storage key for hints for the current player
-- returns nil when not connected to AP
function getHintDataStorageKey()
	if AutoTracker:GetConnectionState("AP") ~= 3 or Archipelago.TeamNumber == nil or Archipelago.TeamNumber == -1 or Archipelago.PlayerNumber == nil or Archipelago.PlayerNumber == -1 then
		if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print("Tried to call getHintDataStorageKey while not connect to AP server")
		end
		return nil
	end
	return string.format("_read_hints_%s_%s", Archipelago.TeamNumber, Archipelago.PlayerNumber)
end

-- resets an item to its initial state
function resetItem(item_code, item_type)
	local obj = Tracker:FindObjectForCode(item_code)
	if obj then
		item_type = item_type or obj.Type
		if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("resetItem: resetting item %s of type %s", item_code, item_type))
		end
		if item_type == "toggle" or item_type == "toggle_badged" then
			obj.Active = false
		elseif item_type == "progressive" or item_type == "progressive_toggle" then
			obj.CurrentStage = 0
			obj.Active = false
		elseif item_type == "consumable" then
			obj.AcquiredCount = 0
		elseif item_type == "custom" then
			-- your code for your custom lua items goes here
		elseif item_type == "static" and AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("resetItem: tried to reset static item %s", item_code))
		elseif item_type == "composite_toggle" and AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format(
				"resetItem: tried to reset composite_toggle item %s but composite_toggle cannot be accessed via lua." ..
				"Please use the respective left/right toggle item codes instead.", item_code))
		elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("resetItem: unknown item type %s for code %s", item_type, item_code))
		end
	elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
		print(string.format("resetItem: could not find item object for code %s", item_code))
	end
end

-- advances the state of an item
function incrementItem(item_code, item_type, multiplier)
	local obj = Tracker:FindObjectForCode(item_code)
	if obj then
		item_type = item_type or obj.Type
		if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			-- print(string.format("incrementItem: code: %s, type %s", item_code, item_type))
		end
		if item_type == "toggle" or item_type == "toggle_badged" then
			obj.Active = true
		elseif item_type == "progressive" or item_type == "progressive_toggle" then
			if obj.Active then
				obj.CurrentStage = obj.CurrentStage + 1
			else
				obj.Active = true
			end
		elseif item_type == "consumable" then
			obj.AcquiredCount = obj.AcquiredCount + obj.Increment * multiplier
		elseif item_type == "custom" then
			-- your code for your custom lua items goes here
		elseif item_type == "static" and AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("incrementItem: tried to increment static item %s", item_code))
		elseif item_type == "composite_toggle" and AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format(
				"incrementItem: tried to increment composite_toggle item %s but composite_toggle cannot be access via lua." ..
				"Please use the respective left/right toggle item codes instead.", item_code))
		elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("incrementItem: unknown item type %s for code %s", item_type, item_code))
		end
	elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
		-- print(string.format("incrementItem: could not find object for code %s", item_code))
	end
end

-- apply everything needed from slot_data, called from onClear
function apply_slot_data(slot_data)
	print(string.format("Slot_data pickup_energy: %s", slot_data['pickup_checks_energy']))
	if slot_data['pickup_checks_energy'] == true then
		Tracker:FindObjectForCode("energy_checks").CurrentStage = 1
	end
	print(string.format("Slot_data pickup_weapon: %s", slot_data['pickup_checks_weapon']))
	if slot_data['pickup_checks_weapon'] == true then
		Tracker:FindObjectForCode("weapon_checks").CurrentStage = 1
	end
	print(string.format("Slot_data pickup_crystals: %s", slot_data['pickup_checks_crystals']))
	if slot_data['pickup_checks_crystals'] == true then
		Tracker:FindObjectForCode("crystal_checks").CurrentStage = 1
	end
	print(string.format("Slot_data pickup_1up: %s", slot_data['pickup_checks_1up']))
	if slot_data['pickup_checks_1up'] == true then
		Tracker:FindObjectForCode("life_checks").CurrentStage = 1
	end


	print(string.format("Slot_data starting_model: %s", slot_data['starting_model']))
	if slot_data['starting_model'] == "none" then
		Tracker:FindObjectForCode("model_hu").CurrentStage = 1
	else
		local modelstart = slot_data['starting_model']
		Tracker:FindObjectForCode(modelstart).CurrentStage = 1
		if slot_data['hu_in_pool'] == false then
			Tracker:FindObjectForCode("model_hu").CurrentStage = 1
		end
	end


	for setting,k in pairs(slot_data["goal_requirements"]) do
		print(string.format("goal req: %s", setting))
		if setting == "missions" then
			print(string.format("missions setting: %s", k))
			Tracker:FindObjectForCode("missions").MaxCount = k
			Tracker:FindObjectForCode("total_missions").MaxCount = k
			if k == 0 then
				Tracker:FindObjectForCode("total_missions").Icon = "images/items/disabled/g.png"
			end
		end
		if setting == "models_count" then
			print(string.format("models setting: %s", k))
			Tracker:FindObjectForCode("total_models").MaxCount = k
			if k == 0 then
				Tracker:FindObjectForCode("total_models").Icon = "images/items/disabled/model x.png"
			end
		end
		if setting == "secret_disks" then
			print(string.format("disks setting: %s", k))
			Tracker:FindObjectForCode("secretdisk").MaxCount = k
			Tracker:FindObjectForCode("total_disks").MaxCount = k
			if k == 0 then
				Tracker:FindObjectForCode("total_disks").Icon = "images/items/disabled/disk.png"
			end
		end
	end

	print(string.format("Slot_data goal_requirements: %s", slot_data['goal_requirements']))

	-- goal_requirements

	-- required_models(_count)
	-- require_full_models

	-- required_secret_disks

	-- required_missions



	-- for k,setting in pairs(slot_data["goal"]) do

	-- 	if setting == "Buster" then
	-- 		print(string.format("weapon setting: %s", setting))
	-- 		local buster = Tracker:FindObjectForCode("buster")
	-- 		buster.CurrentStage = (1)
	-- 	end
	-- 	if setting == "Z-Saber" then
	-- 		print(string.format("weapon setting: %s", setting))
	-- 		local saber = Tracker:FindObjectForCode("saber")
	-- 		saber.CurrentStage = (1)
	-- 	end
	-- 	if setting == "Recoil Rod" then
	-- 		print(string.format("weapon setting: %s", setting))
	-- 		local rod = Tracker:FindObjectForCode("rod")
	-- 		rod.CurrentStage = (1)
	-- 	end
	-- 	if setting == "Shield Boomerang" then
	-- 		print(string.format("weapon setting: %s", setting))
	-- 		local shield = Tracker:FindObjectForCode("shieldboomerang")
	-- 		shield.CurrentStage = (1)
	-- 	end
	-- end


	-- print(string.format("Slot_data required disks: %s", slot_data['required_secret_disks']))
	-- 	local total_disks = Tracker:FindObjectForCode("total_count")
	-- 	total_disks.MaxCount = slot_data['required_secret_disks']
	-- print(string.format("Slot_data starting weapons: %s", slot_data['starting_weapons']))
	-- 	for k,setting in pairs(slot_data["starting_weapons"]) do
	-- 		if setting == "Buster" then
	-- 			print(string.format("weapon setting: %s", setting))
	-- 			local buster = Tracker:FindObjectForCode("buster")
	-- 			buster.CurrentStage = (1)
	-- 		end
	-- 		if setting == "Z-Saber" then
	-- 			print(string.format("weapon setting: %s", setting))
	-- 			local saber = Tracker:FindObjectForCode("saber")
	-- 			saber.CurrentStage = (1)
	-- 		end
	-- 		if setting == "Recoil Rod" then
	-- 			print(string.format("weapon setting: %s", setting))
	-- 			local rod = Tracker:FindObjectForCode("rod")
	-- 			rod.CurrentStage = (1)
	-- 		end
	-- 		if setting == "Shield Boomerang" then
	-- 			print(string.format("weapon setting: %s", setting))
	-- 			local shield = Tracker:FindObjectForCode("shieldboomerang")
	-- 			shield.CurrentStage = (1)
	-- 		end
	-- 	end
	-- print(string.format("Slot_data itemsanity: %s", slot_data['itemsanity']))
	-- 	local itemsanity = Tracker:FindObjectForCode("itemsanity")
	-- 	itemsanity.CurrentStage = (slot_data['itemsanity'])
	-- print(string.format("Slot_data lifesanity: %s", slot_data['extra_life_sanity']))
	-- 	local lifesanity = Tracker:FindObjectForCode("1upsanity")
	-- 	lifesanity.CurrentStage = (slot_data['extra_life_sanity'])

	-- put any code here that slot_data should affect (toggling setting items for example)
end


-- called right after an AP slot is connected
function onClear(slot_data)
	-- use bulk update to pause logic updates until we are done resetting all items/locations
	Tracker.BulkUpdate = true
	if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
		print(string.format("called onClear, slot_data:\n%s", dump_table(slot_data)))
	end
	CUR_INDEX = -1
	-- reset locations
	for _, mapping_entry in pairs(LOCATION_MAPPING) do
		for _, location_table in ipairs(mapping_entry) do
			if location_table then
				local location_code = location_table[1]
				if location_code then
					if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
						print(string.format("onClear: clearing location %s", location_code))
					end
					if location_code:sub(1, 1) == "@" then
						local obj = Tracker:FindObjectForCode(location_code)
						if obj then
							-- obj.AvailableChestCount = obj.ChestCount
							if obj.Highlight then
								obj.Highlight = Highlight.None
							end
						elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
							print(string.format("onClear: could not find location object for code %s", location_code))
						end
					else
						-- reset hosted item
						local item_type = location_table[2]
						resetItem(location_code, item_type)
					end
				elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
					print(string.format("onClear: skipping location_table with no location_code"))
				end
			elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
				print(string.format("onClear: skipping empty location_table"))
			end
		end
	end

	-- reset items
	for _, mapping_entry in pairs(ITEM_MAPPING) do
		for _, item_table in ipairs(mapping_entry) do
			if item_table then
				local item_code = item_table[1]
				local item_type = item_table[2]
				if item_code then
					resetItem(item_code, item_type)
				elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
					print(string.format("onClear: skipping item_table with no item_code"))
				end
			elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
				print(string.format("onClear: skipping empty item_table"))
			end
		end
	end
	
	apply_slot_data(slot_data)
	LOCAL_ITEMS = {}
	GLOBAL_ITEMS = {}
	
	-- setup data storage tracking for hint tracking
	local data_strorage_keys = {}
	if PopVersion >= "0.32.0" then
		data_strorage_keys = { getHintDataStorageKey() }
	end
	-- subscribes to the data storage keys for updates
	-- triggers callback in the SetNotify handler on update
	Archipelago:SetNotify(data_strorage_keys)
	-- gets the current value for the data storage keys
	-- triggers callback in the Retrieved handler when result is received
	Archipelago:Get(data_strorage_keys)
	Tracker.BulkUpdate = false

	-- auto tabbing from MLSS
	PLAYER_ID = Archipelago.PlayerNumber or -1
	TEAM_NUMBER = Archipelago.TeamNumber or 0
        
        if Archipelago.PlayerNumber>-1 then
            updateTabs({0,0,0})
            TAB_ID = "mmzx_pos_"..PLAYER_ID 
            print(string.format("SET NOTIFY %s",TAB_ID))
            Archipelago:SetNotify({TAB_ID})
            Archipelago:Get({TAB_ID})
        end
    
        Tracker:FindObjectForCode("tab_switch").Active = 1
end

-- called when an item gets collected
function onItem(index, item_id, item_name, player_number)
	if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
		-- print(string.format("called onItem: %s, %s, %s, %s, %s", index, item_id, item_name, player_number, CUR_INDEX))
	end
	if not AUTOTRACKER_ENABLE_ITEM_TRACKING then
		return
	end
	if index <= CUR_INDEX then
		return
	end
	local is_local = player_number == Archipelago.PlayerNumber
	CUR_INDEX = index
	local mapping_entry = ITEM_MAPPING[item_id]
	if not mapping_entry then
		if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("onItem: could not find item mapping for id %s", item_id))
		end
		return
	end
	for _, item_table in pairs(mapping_entry) do
		if item_table then
			local item_code = item_table[1]
			local item_type = item_table[2]
			local multiplier = item_table[3] or 1
			if item_code then
				incrementItem(item_code, item_type, multiplier)
				-- keep track which items we touch are local and which are global
				if is_local then
					if LOCAL_ITEMS[item_code] then
						LOCAL_ITEMS[item_code] = LOCAL_ITEMS[item_code] + 1
					else
						LOCAL_ITEMS[item_code] = 1
					end
				else
					if GLOBAL_ITEMS[item_code] then
						GLOBAL_ITEMS[item_code] = GLOBAL_ITEMS[item_code] + 1
					else
						GLOBAL_ITEMS[item_code] = 1
					end
				end
			elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
				print(string.format("onClear: skipping item_table with no item_code"))
			end
		elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("onClear: skipping empty item_table"))
		end
	end
	if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
		--print(string.format("local items: %s", dump_table(LOCAL_ITEMS)))
		--print(string.format("global items: %s", dump_table(GLOBAL_ITEMS)))
	end
	-- track local items via snes interface
	if PopVersion < "0.20.1" or AutoTracker:GetConnectionState("SNES") == 3 then
		-- add snes interface functions for local item tracking here
	end
end

-- called when a location gets cleared
function onLocation(location_id, location_name)
	if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
		-- print(string.format("called onLocation: %s, %s", location_id, location_name))
	end
	if not AUTOTRACKER_ENABLE_LOCATION_TRACKING then
		return
	end
	local mapping_entry = LOCATION_MAPPING[location_id]
	if not mapping_entry then
		if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("onLocation: could not find location mapping for id %s", location_id))
		end
		return
	end
	for _, location_table in pairs(mapping_entry) do
		if location_table then
			-- print(location_table)
			-- print(location_code)
			local location_code = location_table[1]
			if location_code then
				local obj = Tracker:FindObjectForCode(location_code)
				print(string.format("ONLOCATION: %s", obj))
				if obj then
					if location_code:sub(1, 1) == "@" then
						obj.AvailableChestCount = obj.AvailableChestCount - 1
					else
						-- increment hosted item
						local item_type = location_table[2]
						incrementItem(location_code, item_type)
					end
				elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
					print(string.format("onLocation: could not find object for code %s", location_code))
				end
			elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
				print(string.format("onLocation: skipping location_table with no location_code"))
			end
		elseif AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("onLocation: skipping empty location_table"))
		end
	end
end

-- called when a locations is scouted
function onScout(location_id, location_name, item_id, item_name, item_player)
	if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
		print(string.format("called onScout: %s, %s, %s, %s, %s", location_id, location_name, item_id, item_name,
			item_player))
	end
	-- not implemented yet :(
end

-- called when a bounce message is received
function onBounce(json)
	if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
		print(string.format("called onBounce: %s", dump_table(json)))
	end
	-- your code goes here
end


-- auto-map tab from MLSS

function onNotify(key, value, old_value)
	if value ~= old_value then
		if key == TAB_ID then
		  updateTabs(value)
        end
        -- if key == EVENT_ID then
        --     updateEvents(value)
		-- end
	end
end

function onNotifyLaunch(key, value)
    if key == TAB_ID then
        updateTabs(value)
    end
    --   if key == EVENT_ID then
    --       updateEvents(value)
    --   end
end

local lastRoomID = nil

function updateTabs(value)
    if value ~= nil then
		local area = value[1]
		-- print(string.format("called updateTabs, value:\n%s", dump_table(value)))
		print(string.format("called updateTabs, area:%s", area))
        --print(string.format("updateTabs %x", area))
        local tabswitch = Tracker:FindObjectForCode("tab_switch")
        Tracker:FindObjectForCode("cur_level_id").CurrentStage = area
        if tabswitch.Active then
            if value ~= lastRoomID then
				--print(string.format("current level %x", area))
                if TAB_MAPPING[area] then
                    local roomTabs = {}
                    for str in string.gmatch(TAB_MAPPING[area], "([^/]+)") do
                        table.insert(roomTabs, str)
                    end
                    if #roomTabs > 0 then
                        for _, tab in ipairs(roomTabs) do
                            --print(string.format("Updating ID %x to Tab %s", area, tab))
                            Tracker:UiHint("ActivateTab", tab)
                        end
                        lastRoomID = area
                    else
                        print(string.format("Failed to find tabs for ID %x", area))
                    end
                else
                    print(string.format("Failed to find Tab ID %x", area))
                end
            else
            end
        end
    end
end

function updateEvents(value)
    -- if value ~= nil then
    -- 	for _, event in pairs(EVENT_FLAG_MAPPING) do
    -- 		for _, code in pairs(event.codes) do
	-- 			if code.setting == nil or has(code.setting) then
	-- 				if code.code == "harbor_mail" then
	-- 				Tracker:FindObjectForCode(code.code).Active = Tracker:FindObjectForCode(code.code).Active or value & event.bitmask ~= 0
	-- 				else
	-- 				Tracker:FindObjectForCode(code.code).Active = value & event.bitmask ~= 0
	-- 				end
	-- 			end
    --     	end
    -- 	end
    -- end
end


-- called whenever Archipelago:Get returns data from the data storage or
-- whenever a subscribed to (via Archipelago:SetNotify) key in data storgae is updated
-- oldValue might be nil (always nil for "_read" prefixed keys and via retrieved handler (from Archipelago:Get))
function onDataStorageUpdate(key, value, oldValue)
	--if you plan to only use the hints key, you can remove this if
	if key == getHintDataStorageKey() then
		onHintsUpdate(value)
	end
end

-- called whenever the hints key in data storage updated
-- NOTE: this should correctly handle having multiple mapped locations in a section.
--       if you only map sections 1 to 1 you can simplfy this. for an example see
--       https://github.com/Cyb3RGER/sm_ap_tracker/blob/main/scripts/autotracking/archipelago.lua
function onHintsUpdate(hints)
	-- Highlight is only supported since version 0.32.0
	if PopVersion < "0.32.0" or not AUTOTRACKER_ENABLE_LOCATION_TRACKING then
		return
	end
	local player_number = Archipelago.PlayerNumber
	-- get all new highlight values per section
	local sections_to_update = {}
	for _, hint in ipairs(hints) do
		-- we only care about hints in our world
		if hint.finding_player == player_number then
			updateHint(hint, sections_to_update)
		end
	end
	-- update the sections
	for location_code, highlight_code in pairs(sections_to_update) do
		-- find the location object
		local obj = Tracker:FindObjectForCode(location_code)
		-- check if we got the location and if it supports Highlight
		if obj and obj.Highlight then
			obj.Highlight = highlight_code
		end
	end
end

-- update section highlight based on the hint
function updateHint(hint, sections_to_update)
	-- get the highlight enum value for the hint status
	local hint_status = hint.status
	local highlight_code = nil
	if hint_status then
		highlight_code = HINT_STATUS_MAPPING[hint_status]
	end
	if not highlight_code then
		if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("updateHint: unknown hint status %s for hint on location id %s", hint.status,
				hint.location))
		end
		-- try to "recover" by checking hint.found (older AP versions without hint.status)
		if hint.found == true then
			highlight_code = Highlight.None
		elseif hint.found == false then
			highlight_code = Highlight.Unspecified
		else
			return
		end
	end
	-- get the location mapping for the location id
	local mapping_entry = LOCATION_MAPPING[hint.location]
	if not mapping_entry then
		if AUTOTRACKER_ENABLE_DEBUG_LOGGING_AP then
			print(string.format("updateHint: could not find location mapping for id %s", hint.location))
		end
		return
	end
	--get the "highest" highlight value pre section
	for _, location_table in pairs(mapping_entry) do
		if location_table then
			local location_code = location_table[1]
			-- skip hosted items, they don't support Highlight
			if location_code and location_code:sub(1, 1) == "@" then
				-- see if we already set a Highlight for this section
				local existing_highlight_code = sections_to_update[location_code]
				if existing_highlight_code then
					-- make sure we only replace None or "increase" the highlight but never overwrite with None
					-- this so sections with mulitple mapped locations show the "highest" Highlight and
					-- only show no Highlight when all hints are found
					if existing_highlight_code == Highlight.None or (existing_highlight_code < highlight_code and highlight_code ~= Highlight.None) then
						sections_to_update[location_code] = highlight_code
					end
				else
					sections_to_update[location_code] = highlight_code
				end
			end
		end
	end
end

-- add AP callbacks
-- un-/comment as needed
Archipelago:AddClearHandler("clear handler", onClear)
if AUTOTRACKER_ENABLE_ITEM_TRACKING then
	Archipelago:AddItemHandler("item handler", onItem)
end
if AUTOTRACKER_ENABLE_LOCATION_TRACKING then
	Archipelago:AddLocationHandler("location handler", onLocation)
end
Archipelago:AddRetrievedHandler("retrieved handler", onDataStorageUpdate)
Archipelago:AddSetReplyHandler("set reply handler", onDataStorageUpdate)



Archipelago:AddSetReplyHandler("notify handler", onNotify)
Archipelago:AddRetrievedHandler("notify launch handler", onNotifyLaunch)
-- Archipelago:AddScoutHandler("scout handler", onScout)
-- Archipelago:AddBouncedHandler("bounce handler", onBounce)

