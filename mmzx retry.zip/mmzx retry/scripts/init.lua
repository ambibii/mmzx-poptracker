-- entry point for all lua code of the pack
-- more info on the lua API: https://github.com/black-sliver/PopTracker/blob/master/doc/PACKS.md#lua-interface
ENABLE_DEBUG_LOG = true
-- get current variant
local variant = Tracker.ActiveVariantUID
-- check variant info
IS_ITEMS_ONLY = variant:find("itemsonly")

print("-- Example Tracker --")
print("Loaded variant: ", variant)
if ENABLE_DEBUG_LOG then
    print("Debug logging is enabled!")
end

-- Utility Script for helper functions etc.
ScriptHost:LoadScript("scripts/utils.lua")

-- Logic
ScriptHost:LoadScript("scripts/logic/logic.lua")

-- Custom Items
ScriptHost:LoadScript("scripts/custom_items/class.lua")
ScriptHost:LoadScript("scripts/custom_items/progressiveTogglePlus.lua")
ScriptHost:LoadScript("scripts/custom_items/progressiveTogglePlusWrapper.lua")

-- Items
Tracker:AddItems("items/items.jsonc")

if not IS_ITEMS_ONLY then -- <--- use variant info to optimize loading
    -- Maps
    Tracker:AddMaps("maps/maps.jsonc")
    -- Locations
    Tracker:AddLocations("locations/Area A.json")
    Tracker:AddLocations("locations/Area B.json")
    Tracker:AddLocations("locations/Area C.json")
    Tracker:AddLocations("locations/Area D.json")
    Tracker:AddLocations("locations/Area E.json")
    Tracker:AddLocations("locations/Area F.json")
    Tracker:AddLocations("locations/Area G.json")
    Tracker:AddLocations("locations/Area H.json")
    Tracker:AddLocations("locations/Area I.json")
    Tracker:AddLocations("locations/Area J.json")
    Tracker:AddLocations("locations/Area K.json")
    Tracker:AddLocations("locations/Area L.json")
    Tracker:AddLocations("locations/Area M.json")
    Tracker:AddLocations("locations/Area N.json")
    Tracker:AddLocations("locations/Area O.json")
    Tracker:AddLocations("locations/Area X.json")
    Tracker:AddLocations("locations/Overworld.json")
end

-- Layout
Tracker:AddLayouts("layouts/items.jsonc")
Tracker:AddLayouts("layouts/tracker.jsonc")
Tracker:AddLayouts("layouts/broadcast.jsonc")
Tracker:AddLayouts("layouts/tabs.json")

-- AutoTracking for Poptracker
if PopVersion and PopVersion >= "0.18.0" then
    ScriptHost:LoadScript("scripts/autotracking.lua")
end
